Digital Escape Website

Files:
- index.html — Store Homepage
- shop.html — Shop / all products with images and descriptions
- about.html — About Us
- location.html — Location
- cart.html — Cart
- checkout.html — Checkout / order confirmation step
- style.css — external stylesheet linked from every HTML page
- console.jpg, laptop.jpg, games.jpg, pc.jpg — simple local product placeholder images

The proposal specifies the brand colors by name as gray, black, and white. Those color names are used in style.css.
